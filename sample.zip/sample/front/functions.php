<?php
function getApi($url) {
	$json=(file_get_contents($url));
	if (http_response_code()==404) return false;
	else if (http_response_code() == 204) return array();
	else return json_decode($json,true);
}


function szures($mit) {
	$lista=array();
	foreach ($mit as $rekord) {
		if ($rekord["ev"]==intval($_GET["ev"])) 
			array_push($lista,$rekord);
	}
	return $lista;
}
?>
