<?php 
    $mind = getApi($apiUrl."?resztvevo=mind");
    if (!$mind) $mind=[]; 

?>

<label for="szures"></label>
<select id="szures">
    <option value="osszes" selected>Összes</option>
    <option value="donto">Döntő</option>
    <option value="elodonto">Elődöntő</option>
    <option value="elovalogato">Előválogató</option>
</select>

    <div class='page'>
        <?php include_once("ponttabla.php"); ?>
    </div>

