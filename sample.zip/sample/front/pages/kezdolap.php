<div class='page'>
<h1>Magyarország az Eurovíziós Dalfesztiválokon</h1><br>
<h2>Eurovíziós Dalfesztivál</h2><br>
<p>
Az Eurovíziós Dalfesztivál (Eurovision Song Contest) egy 1956 óta évente megrendezésre kerülő verseny, főként az Európai Műsorsugárzók Uniójának (EBU) aktív tagállamai között. A fesztivál keretében minden résztvevő ország benevez egy zeneszámot, amit élő adásban előadnak, majd szavaznak a többi résztvevő által benevezett számokra, hogy megtalálják a verseny legnépszerűbb dalát. Az országok az EBU-tag tévétársaságukon keresztül szerepelnek, melyek feladata az országot képviselő énekes és dal kiválasztása.
</p>
<img src="./front/img/logo_56.png" id="logo56">
<p>
A fesztivált 1956-os kezdése óta minden évben megtartották, így egyike a leghosszabb ideig tartó televíziós műsoroknak a világon. Ez egyben a világ legnagyobb dalversenye a nézők számát tekintve, Európán kívül is számos országban közvetítik annak ellenére, hogy ezek az országok nem vehetnek részt a versenyen.
</p>

<p>
A Dalfesztivált általában a megrendezett popzene fellegvárának tartják, azonban a szereplő dalok stílus tekintetében széles skálán mozognak, van köztük arab, balkáni zene, dance, folk, görög, latin zene, metal, északi zene, pop-rap és rock is. Az évek során, a Dalfesztivál kinőtte magát egyszerű televíziós kísérletből, és egy óriási méretű nemzetközi intézménnyé vált. Európa legtöbb országa részt vett már legalább egyszer a fesztiválon, és az „Eurovízió” (Eurovision) szó ismert az egész kontinensen.
</p>
<h2>Magyar vonatkozások</h2>
<p>
Magyarország 1994 és 2019 között összesen tizenkilenc alkalommal (ebből tizennégyszer a döntőben) vett részt az Eurovíziós Dalfesztiválokon, továbbá kétszer a selejtezőkön (1993-ban és 1996-ban). Az 1990-es években, illetve a 2000-es években Magyarországon nem alakult ki hagyományos, minden évben megrendezett nemzeti válogató. A magyar induló kilétét vagy nemzeti döntő segítségével, vagy nemzeti döntő nélküli belső kiválasztással döntötték el. 2012 óta azonban minden évben megrendezésre kerül a magyar nemzeti döntő, A Dal.
</p>
<p>
Az MTVA a 2020-as Eurovíziós Dalfesztiváltól nem delegált magyar versenyzőt a megmérettetésre.
</p>

</div>