<div class="page">
<p class="center">
	Magyar résztvevő összesen <?php echo count($mind) ?> alkalommal jutott el
	<table class="center">
		<tr><th>Év</th><th>Előadó</th><th>Dal</th><th>Elődöntő hely</th><th>Elődöntő pont</th><th>Döntő hely</th><th>Döntő pont</th></tr>
		<?php
			foreach ($mind as $rekord)
				echo "<tr class='eloadok_sor'>
					<td>$rekord[ev]</td>
					<td>$rekord[eloado]</td>
					<td>$rekord[dal]</td>
					<td>$rekord[edonto]</td>
					<td>$rekord[epont]</td>
					<td>$rekord[donto]</td>
					<td>$rekord[dpont]</td>
				</tr>";
		?>
	</table>
</p>
</div>