<?php
$page="pages/kezdolap.php";
$cim="";

if (isset($_GET['p'])){
	switch ($_GET['p']) {
		case '1': {
			$page = "pages/kezdolap.php";
			break;
		}
		case '2': {
			$page = "pages/resztvevok.php";
			break;
		}
		case '3':{
			$page = "pages/pontszamok.php";
			break;
		}
	}
}

?>