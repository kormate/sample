<main class='page'>
<?php include_once($page); ?>
</main>