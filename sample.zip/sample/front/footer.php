
<footer style="background-color: rgb(254, 254, 192);">
	<div>Forrás: <a target="_blank" href="https://hu.wikipedia.org/wiki/Magyarorsz%C3%A1g_az_Eurov%C3%ADzi%C3%B3s_Dalfesztiv%C3%A1lokon">Wikipédia</a></div>
	<br><br>
	<div class="author">by Kormány Máté - 2024.04.05</div>
	<div class="link">
	<a id="up" href="#pagetop">&#8657;</a>
	</div>
</footer>

</body>
</html>